#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>

#include <ftxui/dom/elements.hpp> 
#include <ftxui/screen/screen.hpp>

using namespace ftxui; 